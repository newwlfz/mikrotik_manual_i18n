# Telemetry Hub

Multi-protocol IoT telemetry ingestion and visualization platform built on InfluxDB and Grafana. Supports data collection from heterogeneous IoT devices via TTN/MQTT, HTTP, and CoAP protocols.

## Overview

Telemetry Hub provides a unified data pipeline for IoT sensor data:

- **InfluxDB 2.7** - Time-series database for telemetry storage
- **Grafana 11.1.0** - Real-time dashboards and visualization
- **Ingest Services** - Protocol-specific data collectors (TTN/MQTT, HTTP, CoAP)

All services are orchestrated via Docker Compose for easy deployment and development.

## Quick Start

### Prerequisites

- Docker and Docker Compose v2
- Git with submodule support
- Ports 3000, 8080, 8086, 5683 available depending on used services

### Installation

```bash
# Clone repository with submodules
git clone --recursive <repository-url>
cd telemt-hub

# Configure environment
cp .env.example .env

# Start all services (InfluxDB auto-initializes on first run)
./manage.sh up
```

Wait ~30 seconds for InfluxDB to initialize on first startup.

### Access Services

- **Grafana**: http://localhost:3000 (admin/admin)
- **InfluxDB**: http://localhost:8086 (admin/adminadmin)

## Architecture

```
IoT Devices
    |
    v
+---+---+---+
|   |   |   |
TTN HTTP CoAP  <-- Ingest Layer
|   |   |   |
+---+---+---+
    |
    v
InfluxDB       <-- Storage Layer
    |
    v
Grafana        <-- Visualization Layer
```

### Components

- **ingest-ttn** - LoRa device data via The Things Network MQTT
- **ingest-http** - HTTP REST API for general IoT devices
- **ingest-coap** - CoAP server for constrained devices
- **influxdb** - Time-series database with Flux query language
- **grafana** - Pre-configured dashboards and datasources

### Data Model

All ingest services write to a unified schema:

- **Measurement**: `sensor_data`
- **Tags**: `device_id`, `source` (ttn/http/coap)
- **Fields**: `temperature`, `humidity`, `battery`, `rssi`, etc.

## Usage

### Sending Data

#### HTTP Endpoint

```bash
curl -X POST http://localhost:8080/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "device_id": "sensor-001",
    "temperature": 23.5,
    "humidity": 65.0
  }'
```

#### CoAP Endpoint

```bash
echo '{"device_id":"sensor-001","temperature":23.5}' | \
  coap-client -m post -t json coap://localhost:5683/data
```

#### TTN MQTT

Configure `.env` with TTN credentials. The service automatically subscribes to uplink messages.

## Management

All management operations are available through the manage.sh. Run `./manage.sh help` for a complete list of commands.

### Common Commands

```bash
# Service Management
./manage.sh up           # Start all services
./manage.sh down         # Stop all services
./manage.sh restart      # Restart services
./manage.sh build        # Rebuild images
./manage.sh clean        # Stop and remove all data (destructive)

# Logs
./manage.sh logs         # View all logs
./manage.sh logs-http    # View HTTP ingest logs only
./manage.sh logs-coap    # View CoAP ingest logs only

# Data Management
./manage.sh backup       # Backup InfluxDB data
./manage.sh restore      # Restore from latest backup
./manage.sh clear-data   # Clear telemetry data

# Testing
./manage.sh test-setup   # Setup test environment
./manage.sh test         # Generate test data
```

## Repository Structure

```
telemt-hub/
├── docker-compose.yml      # Service orchestration
├── .env.example            # Configuration template
├── ./manage.sh             # Management interface
├── grafana/                # Grafana provisioning
├── influxdb/               # InfluxDB init scripts
└── ingest-ttn/             # TTN MQTT ingest
```

Each service (grafana, influxdb, ingest-*) is a separate Git repository added as a submodule for independent versioning and development.

## Configuration

Configuration is managed via `.env` file:

```bash
# InfluxDB
INFLUXDB_INIT_USERNAME=admin
INFLUXDB_INIT_PASSWORD=adminadmin
INFLUXDB_INIT_ORG=mt-iot
INFLUXDB_INIT_BUCKET=telemetry
INFLUXDB_INIT_ADMIN_TOKEN=changeme-super-token

# Grafana
GRAFANA_ADMIN_USER=admin
GRAFANA_ADMIN_PASSWORD=adminadmin

# TTN MQTT (optional)
TTN_MQTT_URL=ssl://eu1.cloud.thethings.network:8883
TTN_APP_ID=your-app
TTN_USERNAME=your-app@ttn
TTN_PASSWORD=your-api-key
```

**Important**: Change default passwords and tokens in production.

## Development

### Adding a New Ingest Service

1. Create new repository for the service
2. Implement service following existing patterns
3. Write to same InfluxDB schema (`sensor_data` measurement)
4. Add as submodule: `git submodule add <repo-url> <service-name>`
5. Add service to `docker-compose.yml`

## Troubleshooting

### Services won't start

```bash
# Check logs
docker compose logs

# Check port availability
sudo lsof -i :3000
sudo lsof -i :8086
sudo lsof -i :8080
```

### No data in Grafana

1. Verify InfluxDB is initialized (see Quick Start)
2. Test endpoint: `curl -X POST http://localhost:8080/ingest -H 'Content-Type: application/json' -d '{"device_id":"test","temperature":25}'`
3. Check ingest service logs: `docker compose logs ingest-http`
4. Restart Grafana: `docker compose restart grafana`

### InfluxDB authorization errors

If you see "unauthorized access" errors, InfluxDB may have failed to initialize properly.

1. Check InfluxDB logs: `./manage.sh logs-influxdb`
2. Verify `.env` credentials match expected values
3. If needed, reset InfluxDB:
   ```bash
   ./manage.sh down
   docker volume rm telemt-hub_influx-data
   ./manage.sh up
   ```
   Wait ~30 seconds for re-initialization
