#! /bin/bash

# "IOT Telemetry Hub management utility"

ENV_FILE=${2:-.env}

if [ ! -f "$ENV_FILE" ]; then
   echo "Environment file: '$ENV_FILE' not found, see example/env/.env"
   exit 1
fi

. "$ENV_FILE"

CMD_LIST="up down logs logs-influxdb logs-grafana logs-http logs-coap logs-ttn restart clean backup restore clear-data test test-setup help"

help() {
	echo "Telemetry Hub - Management Interface"
	echo ""
	echo "Service Management:"
	echo "  up              - Start all services in detached mode"
	echo "  down            - Stop and remove all containers"
	echo "  restart         - Restart all services"
	echo "  clean           - Stop containers and remove volumes (DATA LOSS!)"
	echo ""
	echo "Logs:"
	echo "  logs            - Follow logs from all services"
	echo "  logs-influxdb   - Follow logs from InfluxDB only"
	echo "  logs-grafana    - Follow logs from Grafana only"
	echo "  logs-http       - Follow logs from HTTP ingest service"
	echo "  logs-coap       - Follow logs from CoAP ingest service"
	echo "  logs-ttn        - Follow logs from TTN ingest service"
	echo ""
	echo "Help:"
	echo "  help            - Show this help message"
}

# Service Management
up() {
	make_volumes
	docker compose up -d
}

down() {
	docker compose down
}

restart() {
	make_volumes
	docker compose restart
}

build() {
	make_volumes
	docker compose build
}

make_volume_dir() {
	if [[ ! -d $1 ]]; then
		echo "Creating: $1"
		mkdir -p $1
		chmod -Rc a+rw $1
	fi
}

make_volumes() {
	make_volume_dir $GRAFANA_DATA_PATH
	make_volume_dir $INFLUX_DATA_PATH
}

clean() {
	echo "Will delte bind volume: $GRAFANA_DATA_PATH"
	echo "Will delte bind volume: $INFLUX_DATA_PATH"
	read -p "Are you sure? [y/N] " -n 1 -r
	echo
	if [[ $REPLY =~ ^[Yy]$ ]]; then
		docker compose down -v
		rm -rf $GRAFANA_DATA_PATH
		rm -rf $INFLUX_DATA_PATH
		echo "Done!"
	else
		echo "Canceled by user!"
	fi
}

# Logs
logs() {
	docker compose logs -f
}

logs-influxdb() {
	docker compose logs -f influxdb
}

logs-grafana() {
	docker compose logs -f grafana
}

logs-http() {
	docker compose logs -f ingest-http
}

logs-coap() {
	docker compose logs -f ingest-coap
}

logs-ttn() {
	docker compose logs -f ingest-ttn
}

for cmd in $CMD_LIST
do
	if [[ $1 == $cmd ]]; then
		$cmd
		exit $?
	fi
done

help
