#!/bin/bash
# Create bucket in InfluxDB
# This script is executed automatically by InfluxDB on first run

set -e

echo "Checking if bucket exists..."

# The bucket is created automatically via INFLUXDB_INIT_BUCKET
# This script can be used for additional buckets or custom retention policies

if [ -n "${INFLUXDB_INIT_BUCKET}" ]; then
    echo "Bucket '${INFLUXDB_INIT_BUCKET}' will be created automatically by InfluxDB init"
    echo "Retention: infinite (default)"
else
    echo "Warning: INFLUXDB_INIT_BUCKET not set"
fi

# Example: Create additional bucket with 30-day retention
# influx bucket create \
#   --name telemetry-archive \
#   --org ${INFLUXDB_INIT_ORG} \
#   --retention 720h \
#   --token ${INFLUXDB_INIT_ADMIN_TOKEN}
