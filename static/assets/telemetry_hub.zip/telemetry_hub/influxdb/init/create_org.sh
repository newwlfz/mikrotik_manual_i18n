#!/bin/bash
# Create organization in InfluxDB
# This script is executed automatically by InfluxDB on first run

set -e

echo "Checking if organization exists..."

# The organization is created automatically via INFLUXDB_INIT_ORG
# This script can be used for additional organizations or verification

if [ -n "${INFLUXDB_INIT_ORG}" ]; then
    echo "Organization '${INFLUXDB_INIT_ORG}' will be created automatically by InfluxDB init"
else
    echo "Warning: INFLUXDB_INIT_ORG not set"
fi
