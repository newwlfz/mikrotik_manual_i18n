#!/usr/bin/env python3
"""
TTN MQTT Ingest Service
Subscribes to The Things Network MQTT broker and forwards telemetry to InfluxDB
"""

import os
import json
import time
import logging
from datetime import datetime
import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

# Environment variables
TTN_MQTT_URL = os.getenv('TTN_MQTT_URL', 'ssl://eu1.cloud.thethings.network:8883')
TTN_APP_ID = os.getenv('TTN_APP_ID')
TTN_USERNAME = os.getenv('TTN_USERNAME')
TTN_PASSWORD = os.getenv('TTN_PASSWORD')
INFLUX_URL = os.getenv('INFLUX_URL', 'http://influxdb:8086')
INFLUX_TOKEN = os.getenv('INFLUX_TOKEN')
INFLUX_ORG = os.getenv('INFLUX_ORG', 'mt-iot')
INFLUX_BUCKET = os.getenv('INFLUX_BUCKET', 'telemetry')
TTN_LOG_LEVEL = os.getenv('TTN_LOG_LEVEL', "INFO")

# Configure logging
logging.basicConfig(
    level=TTN_LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Parse MQTT URL
mqtt_parts = TTN_MQTT_URL.replace('ssl://', '').replace('mqtt://', '').split(':')
MQTT_HOST = mqtt_parts[0]
MQTT_PORT = int(mqtt_parts[1]) if len(mqtt_parts) > 1 else 8883
MQTT_USE_SSL = TTN_MQTT_URL.startswith('ssl://')

# InfluxDB client
influx_client = None
write_api = None


def init_influx():
    """Initialize InfluxDB client"""
    global influx_client, write_api

    try:
        influx_client = InfluxDBClient(
            url=INFLUX_URL,
            token=INFLUX_TOKEN,
            org=INFLUX_ORG
        )
        write_api = influx_client.write_api(write_options=SYNCHRONOUS)
        logger.info(f"Connected to InfluxDB at {INFLUX_URL}")
    except Exception as e:
        logger.error(f"Failed to connect to InfluxDB: {e}")
        raise


def time_now():
    return datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')


def parse_ttn_payload(payload, topic):
    """
    Parse TTN uplink message and extract telemetry data
    """
    try:
        data = json.loads(payload)

        # logger.debug(f"=====================")
        # logger.debug(f"FULL-MSG: {data}")
        # logger.debug(f"=====================")

        # Mandatory
        dev_id = {'device_id': str(data['end_device_ids']['device_id'])}
        dev_id['dev_eui'] = str(data['end_device_ids']['dev_eui'])
        dev_data = {
            'time': str(data['received_at']),
            'source_event': "join" if topic.endswith('/join') else "uplink"
        }

        # Optional
        if 'uplink_message' in data:
            uplink = data.get('uplink_message', {})
            settings = uplink.get('settings', {})

            # Extract metadata
            rx_metadata = uplink.get('rx_metadata', [])

            rssi = -178
            snr = -30

            for rx_gw in rx_metadata:
                if 'rssi' in rx_gw and 'snr' in rx_gw:
                    gw_rssi = float(rx_gw['rssi'])
                    if gw_rssi >= rssi:
                        rssi = gw_rssi
                        snr = rx_gw['snr']

            dev_data |= {
                'f_port': int(uplink.get('f_port', 0)),
                'rssi': float(rssi),
                'snr': float(snr),
                'gw-cnt': len(rx_metadata),
                'frequency': float(settings.get('frequency', 0)),
                'lora_sf': int(settings.get('data_rate', 0).get('lora', 0).get('spreading_factor', 0)),
                'lora_cr': str(settings.get('data_rate', 0).get('lora', 0).get('coding_rate', 0)),
                'bandwidth': float(settings.get('data_rate', 0).get('lora', 0).get('bandwidth', 0))
            }

            dev_data |= uplink.get('decoded_payload', {})

        return dev_id, dev_data

    except Exception as e:
        logger.error(f"Failed to parse TTN payload: {e}")
        return None, None


def write_to_influx(device_id, data):
    """Write telemetry data to InfluxDB"""

    try:
        logger.debug(f"InfluxDB write: {device_id}: {data}")

        point = Point("sensor_data") \
            .tag("device_id", device_id['device_id']) \
            .tag("dev_eui", device_id['dev_eui']) \
            .tag("source", "ttn") \
            .tag("app", "tg-lrx2")

        # Add decoded payload fields
        for key, value in data.items():
            if isinstance(value, (int, float)):
                point.field(key, float(value))
            else:
                point.field(key, str(value))

        point.time(data['time'])

        write_api.write(bucket=INFLUX_BUCKET, record=point)
        logger.info(f"Written data for device {device_id} to InfluxDB")

    except Exception as e:
        logger.error(f"Failed to write to InfluxDB: {e}")


def on_connect(client, userdata, flags, rc):
    """MQTT connection callback"""
    if rc == 0:
        logger.info("Connected to TTN MQTT broker")
        topic = f"v3/{TTN_APP_ID}/devices/#"
        client.subscribe(topic)
        logger.info(f"Subscribed to topic: {topic}")
    else:
        logger.error(f"Failed to connect to MQTT broker, return code: {rc}")


def on_message(client, userdata, msg):
    """MQTT message callback"""
    logger.info(f"Received message on topic: {msg.topic}")

    dev_id, dev_data = parse_ttn_payload(msg.payload, msg.topic)
    if dev_id and dev_data:
        logger.debug(f"processed uplink: {dev_id}: {dev_data}")
        # Extract event data
        events = dev_data.pop('events', [])
        # Write frame data
        write_to_influx(dev_id, dev_data)
        # Write event data
        for event in events:
            write_to_influx(dev_id, event)


def on_disconnect(client, userdata, rc):
    """MQTT disconnect callback"""
    if rc != 0:
        logger.warning(f"Unexpected disconnection from MQTT broker, code: {rc}")
        logger.info("Attempting to reconnect...")


def main():
    """Main entry point"""
    logger.info("Starting TTN MQTT Ingest Service")

    # Validate configuration
    if not all([TTN_APP_ID, TTN_USERNAME, TTN_PASSWORD, INFLUX_TOKEN]):
        logger.error("Missing required environment variables")
        logger.error("Required: TTN_APP_ID, TTN_USERNAME, TTN_PASSWORD, INFLUX_TOKEN")
        return

    logger.info(f"TTN_MQTT_URL: {TTN_MQTT_URL}")
    logger.info(f"TTN_APP_ID: {TTN_APP_ID}")
    logger.info(f"TTN_USERNAME: {TTN_USERNAME}")
    logger.info(f"INFLUX_URL: {INFLUX_URL}")
    logger.info(f"INFLUX_ORG: {INFLUX_ORG}")
    logger.info(f"INFLUX_BUCKET: {INFLUX_BUCKET}")
    logger.info(f"TTN_LOG_LEVEL: {TTN_LOG_LEVEL}")

    # Initialize InfluxDB
    init_influx()

    # Create MQTT client
    client = mqtt.Client(client_id=f"ttn-ingest-{int(time.time())}")
    client.username_pw_set(TTN_USERNAME, TTN_PASSWORD)

    if MQTT_USE_SSL:
        client.tls_set()

    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect

    # Connect and start loop
    logger.info(f"Connecting to {MQTT_HOST}:{MQTT_PORT}")
    client.connect(MQTT_HOST, MQTT_PORT, keepalive=60)

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        client.disconnect()
        influx_client.close()


if __name__ == '__main__':
    main()
