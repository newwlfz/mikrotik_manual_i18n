# TTN MQTT Ingest Service

Subscribes to The Things Network (TTN) MQTT broker and forwards LoRa device telemetry to InfluxDB.

## Features

- Connects to TTN v3 MQTT broker via SSL
- Subscribes to all device uplinks for a specific application
- Parses decoded payloads and metadata
- Writes telemetry data to InfluxDB with proper tags and fields
- Automatic reconnection on disconnect

## Configuration

Set these environment variables in `.env`:

```bash
# TTN Configuration
TTN_MQTT_URL=ssl://eu1.cloud.thethings.network:8883
TTN_APP_ID=your-app
TTN_USERNAME=your-app@ttn
TTN_PASSWORD=NNSXS.YOUR.API.KEY

# InfluxDB Configuration
INFLUX_URL=http://influxdb:8086
INFLUX_TOKEN=changeme-super-token
INFLUX_ORG=mt-iot
INFLUX_BUCKET=telemetry
```

## TTN MQTT API Key

1. Go to TTN Console → Applications → Your App
2. Navigate to Integrations → MQTT
3. Generate a new API key with subscribe permissions
4. Use format: `your-app@ttn` for username
5. Use the API key as password

## Expected TTN Payload Format

The service expects TTN v3 uplink messages:

```json
{
  "end_device_ids": {
    "device_id": "lora-node-01"
  },
  "uplink_message": {
    "decoded_payload": {
      "temperature": 23.5,
      "humidity": 65
    },
    "rx_metadata": [{
      "rssi": -85,
      "snr": 9.5
    }]
  }
}
```

## InfluxDB Schema

**Measurement**: `sensor_data`

**Tags**:
- `device_id` - TTN device ID
- `source` - Always "ttn"

**Fields**:
- `temperature` - Temperature (°C)
- `humidity` - Humidity (%)
- `battery` - Battery level (%)
- `rssi` - Signal strength (dBm)
- `snr` - Signal-to-noise ratio (dB)
- Additional fields from decoded payload

## Running Standalone

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export TTN_APP_ID=your-app
export TTN_USERNAME=your-app@ttn
export TTN_PASSWORD=NNSXS.YOUR.API.KEY
export INFLUX_TOKEN=your-token

# Run
python main.py
```

## Docker Build

```bash
docker build -t ingest-ttn .
docker run --env-file .env ingest-ttn
```

## Logs

The service logs all received messages and write operations:

```
2025-10-23 10:30:15 - INFO - Connected to TTN MQTT broker
2025-10-23 10:30:15 - INFO - Subscribed to topic: v3/your-app/devices/+/up
2025-10-23 10:31:42 - INFO - Received message on topic: v3/your-app/devices/lora-node-01/up
2025-10-23 10:31:42 - INFO - Written data for device lora-node-01 to InfluxDB
```

## Troubleshooting

**Connection refused to TTN**:
- Check your API key has not expired
- Verify username format: `app-id@ttn`
- Ensure your region is correct (eu1, nam1, au1)

**No data in InfluxDB**:
- Check InfluxDB token has write permissions
- Verify bucket name matches configuration
- Check logs for parsing errors
